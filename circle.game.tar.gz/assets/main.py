import asyncio
import math
import random
import re
import sys

import pygame

pygame.init()

# -------------------- WINDOW / GRAPH --------------------
WIDTH, HEIGHT = 1200, 850
GRAPH_SIZE = 760
GRAPH_LEFT = 25
GRAPH_TOP = 55
PANEL_LEFT = 820

MIN_COORD = -20
MAX_COORD = 20
SCALE = GRAPH_SIZE / (MAX_COORD - MIN_COORD)

SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Turtle Line Escape")
CLOCK = pygame.time.Clock()

FONT = pygame.font.SysFont("arial", 22)
SMALL_FONT = pygame.font.SysFont("arial", 17)
TINY_FONT = pygame.font.SysFont("arial", 14)
BIG_FONT = pygame.font.SysFont("arial", 34, bold=True)
TITLE_FONT = pygame.font.SysFont("arial", 27, bold=True)

WHITE = (255, 255, 255)
BLACK = (25, 25, 25)
GRID = (224, 227, 232)
AXIS = (90, 95, 105)
BLUE = (45, 105, 210)
RED = (210, 65, 65)
GREEN = (30, 145, 75)
DARK_GREEN = (15, 105, 55)
ORANGE = (235, 145, 40)
PURPLE = (125, 80, 190)
BROWN = (130, 90, 55)
GREY = (115, 120, 130)
LIGHT_PANEL = (247, 248, 250)
YELLOW = (245, 205, 55)


HAWK_COUNTS = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]

# Physical platforms. The x-axis itself is NOT a floor.
START_X1, START_X2 = MIN_COORD, -14.0
FINISH_X1, FINISH_X2 = 14.0, MAX_COORD
PLATFORM_Y = 0.0

TURTLE_SPEED = 4.2       # graph units / second
FALL_SPEED = 8.0
TURTLE_RADIUS = 0.55
HAWK_RADIUS = 0.38
INTERSECTION_TOL = 0.85
INTERSECTION_GRACE = 0.0
LAND_TOL = 0.18


# -------------------- HELPERS --------------------
def graph_to_screen(gx, gy):
    sx = GRAPH_LEFT + (gx - MIN_COORD) * SCALE
    sy = GRAPH_TOP + (MAX_COORD - gy) * SCALE
    return int(round(sx)), int(round(sy))


def screen_inside_graph(sx, sy):
    return (
        GRAPH_LEFT <= sx <= GRAPH_LEFT + GRAPH_SIZE
        and GRAPH_TOP <= sy <= GRAPH_TOP + GRAPH_SIZE
    )


def clean_math_text(text):
    """Make equation input easier to parse."""
    return text.strip().lower().replace(" ", "").replace("−", "-")


def parse_number(text):
    """Convert a simple signed decimal/fraction to a float."""
    text = text.strip()
    if text in ("", "+"):
        return 1.0
    if text == "-":
        return -1.0

    if "/" in text:
        if text.count("/") != 1:
            raise ValueError("Use a simple number or fraction.")
        numerator, denominator = text.split("/")
        value = float(numerator) / float(denominator)
        return value

    return float(text)


def parse_linear_equation(text):
    """
    Accept only beginner-friendly linear forms:
        y = mx + b
        y = b
        x = a

    Examples:
        y=2x+5
        y=-x+3
        y=0.5x-4
        y=3/2x+1
        y=6
        x=-4
    """
    original = text.strip()
    text = clean_math_text(text)

    if text.count("=") != 1:
        raise ValueError("Use one equals sign.")

    left, right = text.split("=")

    if left not in ("x", "y") or not right:
        raise ValueError("Use y = mx + b, y = b, or x = a.")

    # Vertical line: x = a  ->  x - a = 0
    if left == "x":
        if "x" in right or "y" in right:
            raise ValueError("For a vertical line, use x = a. Example: x = 4.")
        try:
            a = parse_number(right)
        except (ValueError, ZeroDivisionError):
            raise ValueError("For a vertical line, use x = a. Example: x = 4.")
        return Line(1.0, 0.0, -a, original)

    # Horizontal line: y = b
    if "x" not in right:
        if "y" in right:
            raise ValueError("Use y = mx + b, y = b, or x = a.")
        try:
            b = parse_number(right)
        except (ValueError, ZeroDivisionError):
            raise ValueError("For a horizontal line, use y = b. Example: y = 5.")
        return Line(0.0, 1.0, -b, original)

    # Sloped line: y = mx + b
    if right.count("x") != 1 or "y" in right:
        raise ValueError("Use y = mx + b. Example: y = 2x + 5.")

    x_pos = right.index("x")
    m_text = right[:x_pos]
    b_text = right[x_pos + 1:]

    try:
        m = parse_number(m_text)

        if b_text == "":
            b = 0.0
        else:
            # The part after x must begin with + or -.
            if b_text[0] not in "+-":
                raise ValueError
            b = parse_number(b_text)
    except (ValueError, ZeroDivisionError):
        raise ValueError(
            "Use y = mx + b. Examples: y = 2x + 5, y = -x - 3, y = 0.5x."
        )

    # y = mx + b  ->  mx - y + b = 0
    return Line(m, -1.0, b, original)


def point_on_segment(px, py, x1, y1, x2, y2, tol=0.25):
    cross = abs((px - x1) * (y2 - y1) - (py - y1) * (x2 - x1))
    length = math.hypot(x2 - x1, y2 - y1)
    if length == 0 or cross / length > tol:
        return False
    dot = (px - x1) * (px - x2) + (py - y1) * (py - y2)
    return dot <= tol


def wrap_text(text, font, max_width):
    words = text.split()
    lines, current = [], ""
    for word in words:
        trial = word if not current else current + " " + word
        if font.size(trial)[0] <= max_width:
            current = trial
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


# -------------------- LINE OBJECT --------------------
class Line:
    def __init__(self, A, B, C, label=""):
        self.A = A
        self.B = B
        self.C = C
        self.label = label
        # A direction vector along Ax + By + C = 0 is (B, -A)
        length = math.hypot(B, -A)
        self.dx = B / length
        self.dy = -A / length

    @property
    def vertical(self):
        return abs(self.B) < 1e-9

    def signed_value(self, px, py):
        return self.A * px + self.B * py + self.C

    def intersection(self, other):
        det = self.A * other.B - other.A * self.B
        if abs(det) < 1e-9:
            return None
        ix = (self.B * other.C - other.B * self.C) / det
        iy = (self.C * other.A - other.C * self.A) / det
        return ix, iy

    def visible_endpoints(self):
        pts = []

        if abs(self.B) > 1e-9:
            for gx in (MIN_COORD, MAX_COORD):
                gy = -(self.A * gx + self.C) / self.B
                if MIN_COORD - 1e-8 <= gy <= MAX_COORD + 1e-8:
                    pts.append((gx, gy))

        if abs(self.A) > 1e-9:
            for gy in (MIN_COORD, MAX_COORD):
                gx = -(self.B * gy + self.C) / self.A
                if MIN_COORD - 1e-8 <= gx <= MAX_COORD + 1e-8:
                    pts.append((gx, gy))

        unique = []
        for p in pts:
            if not any(math.dist(p, q) < 1e-6 for q in unique):
                unique.append(p)
        return unique[:2]

    def y_at(self, gx):
        if abs(self.B) < 1e-9:
            return None
        return -(self.A * gx + self.C) / self.B


# -------------------- UI --------------------
class InputBox:
    def __init__(self, x0, y0, w, h):
        self.rect = pygame.Rect(x0, y0, w, h)
        self.text = ""
        self.active = False

    def handle_event(self, event):
        submitted = False
        empty_backspace = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            self.active = self.rect.collidepoint(event.pos)

        if event.type == pygame.KEYDOWN and self.active:
            if event.key == pygame.K_RETURN:
                submitted = True
            elif event.key == pygame.K_BACKSPACE:
                if self.text:
                    self.text = self.text[:-1]
                else:
                    empty_backspace = True
            elif event.unicode and event.unicode.isprintable():
                self.text += event.unicode

        return submitted, empty_backspace

    def draw(self):
        colour = BLUE if self.active else GREY
        pygame.draw.rect(SCREEN, WHITE, self.rect)
        pygame.draw.rect(SCREEN, colour, self.rect, 2, border_radius=5)
        txt = FONT.render(self.text, True, BLACK)
        SCREEN.blit(txt, (self.rect.x + 8, self.rect.y + 7))


class Button:
    def __init__(self, x0, y0, w, h, text):
        self.rect = pygame.Rect(x0, y0, w, h)
        self.text = text

    def clicked(self, event):
        return event.type == pygame.MOUSEBUTTONDOWN and self.rect.collidepoint(event.pos)

    def draw(self):
        pygame.draw.rect(SCREEN, WHITE, self.rect, border_radius=7)
        pygame.draw.rect(SCREEN, BLUE, self.rect, 2, border_radius=7)
        surf = FONT.render(self.text, True, BLUE)
        SCREEN.blit(
            surf,
            (
                self.rect.centerx - surf.get_width() // 2,
                self.rect.centery - surf.get_height() // 2,
            ),
        )


# -------------------- HAWKS --------------------
class Hawk:
    def __init__(self, line, t, direction, speed):
        self.line = line
        self.t = t
        self.direction = direction
        self.speed = speed
        self.allowed_inside = None

    def position(self):
        # point nearest origin on line, plus t * direction vector
        denom = self.line.A ** 2 + self.line.B ** 2
        bx = -self.line.A * self.line.C / denom
        by = -self.line.B * self.line.C / denom
        return bx + self.line.dx * self.t, by + self.line.dy * self.t

    def update(self, dt, circle_radius):
        old_t = self.t
        old_x, old_y = self.position()

        self.t += self.direction * self.speed * dt
        nx, ny = self.position()

        # Reverse at graph boundary.
        if not (MIN_COORD + 0.5 <= nx <= MAX_COORD - 0.5 and MIN_COORD + 0.5 <= ny <= MAX_COORD - 0.5):
            self.t = old_t
            self.direction *= -1
            return

        # Circle is a barrier: preserve whichever side the hawk was assigned to.
        if circle_radius is not None and self.allowed_inside is not None:
            inside_next = math.hypot(nx, ny) <= circle_radius
            if inside_next != self.allowed_inside:
                self.t = old_t
                self.direction *= -1

    def draw(self):
        gx, gy = self.position()
        sx, sy = graph_to_screen(gx, gy)
        r = max(5, int(HAWK_RADIUS * SCALE))
        pygame.draw.circle(SCREEN, RED, (sx, sy), r)
        pygame.draw.circle(SCREEN, BLACK, (sx, sy), r, 1)


# -------------------- GAME --------------------
class Game:
    def __init__(self):
        self.line_input = InputBox(PANEL_LEFT, 185, 345, 43)
        self.circle_input = InputBox(PANEL_LEFT, 350, 345, 43)
        self.next_button = Button(PANEL_LEFT, 770, 160, 46, "Next Level")
        self.retry_button = Button(PANEL_LEFT, 770, 140, 46, "Try Again")
        self.restart_button = Button(PANEL_LEFT, 770, 170, 46, "Restart Game")

        self.level = 0
        self.state = "playing"
        self.start_level()

    def start_level(self):
        self.state = "playing"
        self.lines = []
        self.circle_radius = None
        self.line_input.text = ""
        self.circle_input.text = ""
        self.message = "Create paths and choose when to trap the hawks."
        self.message_colour = BLACK

        # Turtle starts on the left ledge.
        self.turtle_x = START_X1 + 1.0
        self.turtle_y = PLATFORM_Y
        self.turtle_angle = 0.0
        self.turtle_path = "start"
        self.turtle_line = None
        self.falling = False
        self.fall_old_y = self.turtle_y
        self.vertical_move_key = None
        self.cached_switch_line = None
        self.cached_switch_point = None
        self.switch_grace = 0.0

        self.hawks = self.make_hawks(HAWK_COUNTS[self.level])

    def make_hawks(self, count):
        hawks = []

        # Every hawk line passes within this many graph units of the origin.
        # This keeps central capture opportunities possible without forcing
        # all hawks through the exact origin.
        for i in range(count):
            angle = random.uniform(math.radians(15), math.radians(165))
            dx, dy = math.cos(angle), math.sin(angle)

            # Normal vector and a modest offset from the origin.
            nx, ny = -dy, dx
            offset = random.uniform(-6.5, 6.5)
            A, B = nx, ny
            C = -offset

            line = Line(A, B, C, "hawk path")

            # Spread starting positions but bias many toward the central region.
            if i < max(1, count // 2):
                t = random.uniform(-8, 8)
            else:
                t = random.uniform(-16, 16)

            speed = random.uniform(3.2, 5.9)
            direction = random.choice((-1, 1))
            hawks.append(Hawk(line, t, direction, speed))

        return hawks

    def create_circle(self):
        text = self.circle_input.text.strip()
        if not text:
            self.remove_circle()
            return

        try:
            value = float(text)
            if value <= 0:
                raise ValueError
            radius = math.sqrt(value)
            if radius > 30:
                self.message = "That circle is too large for this game."
                self.message_colour = RED
                return
        except ValueError:
            self.message = "Enter a positive number for x² + y²."
            self.message_colour = RED
            return

        self.circle_radius = radius

        caught = 0
        for hawk in self.hawks:
            hx, hy = hawk.position()
            hawk.allowed_inside = math.hypot(hx, hy) <= radius
            if hawk.allowed_inside:
                caught += 1

        outside = len(self.hawks) - caught
        if outside == 0:
            self.message = "Safe to go!"
            self.message_colour = DARK_GREEN
        elif caught > 0 and outside <= 3:
            self.message = "Safer to go. Still be careful!"
            self.message_colour = ORANGE
        else:
            self.message = "Still dangerous!"
            self.message_colour = RED

    def remove_circle(self):
        self.circle_radius = None
        self.circle_input.text = ""
        for hawk in self.hawks:
            hawk.allowed_inside = None
        self.message = "Circle removed."
        self.message_colour = BLACK

    def add_line(self):
        text = self.line_input.text.strip()
        if not text:
            return
        try:
            line = parse_linear_equation(text)
        except Exception as exc:
            self.message = str(exc) if str(exc) else "Enter a valid linear equation."
            self.message_colour = RED
            return

        self.lines.append(line)
        self.line_input.text = ""
        self.message = "Line added. Press a new arrow key while touching a highlighted crossing to switch."
        self.message_colour = BLUE

    def delete_latest_line(self):
        if not self.lines:
            self.message = "There are no lines to erase."
            self.message_colour = GREY
            return

        removed = self.lines.pop()

        if self.turtle_line is removed:
            self.turtle_line = None
            self.turtle_path = None
            self.falling = True
            self.fall_old_y = self.turtle_y
            self.message = "You erased the turtle's path — it's falling!"
            self.message_colour = RED
        else:
            self.message = "Most recent line erased."
            self.message_colour = BLACK

    def nearest_usable_intersection(self):
        """Find the closest valid intersection with ANY other student line."""
        if not self.lines or self.falling or self.turtle_path == "finish":
            return None, None

        best_line = None
        best_point = None
        best_distance = float("inf")

        for candidate in self.lines:
            if candidate is self.turtle_line:
                continue

            p = None

            if self.turtle_path == "start":
                # Start ledge is y=0 and only exists over the start platform.
                if abs(candidate.A) < 1e-9:
                    continue
                ix = -candidate.C / candidate.A
                if START_X1 <= ix <= START_X2:
                    p = (ix, 0.0)

            elif self.turtle_line is not None:
                p = self.turtle_line.intersection(candidate)
                if p is not None:
                    if not (MIN_COORD <= p[0] <= MAX_COORD and MIN_COORD <= p[1] <= MAX_COORD):
                        p = None

            if p is None:
                continue

            distance = math.dist((self.turtle_x, self.turtle_y), p)
            if distance < best_distance:
                best_distance = distance
                best_line = candidate
                best_point = p

        return best_line, best_point

    def near_intersection(self):
        """Return the nearest crossing only while the turtle is in contact with it."""
        line, p = self.nearest_usable_intersection()
        if line is None or p is None:
            return None, None
        if math.dist((self.turtle_x, self.turtle_y), p) <= INTERSECTION_TOL:
            return line, p
        return None, None

    def direction_for_key(self, line, key_name):
        """Return a unit direction along line that matches the arrow key."""
        dx, dy = line.dx, line.dy
        eps = 1e-9

        if key_name == "right":
            if abs(dx) < eps:
                return None
            if dx < 0:
                dx, dy = -dx, -dy
        elif key_name == "left":
            if abs(dx) < eps:
                return None
            if dx > 0:
                dx, dy = -dx, -dy
        elif key_name == "up":
            if abs(dy) < eps:
                return None
            if dy < 0:
                dx, dy = -dx, -dy
        elif key_name == "down":
            if abs(dy) < eps:
                return None
            if dy > 0:
                dx, dy = -dx, -dy
        else:
            return None

        return dx, dy

    def switch_to_line(self, key_name):
        line, p = self.near_intersection()
        if line is None or p is None:
            return False

        direction = self.direction_for_key(line, key_name)
        if direction is None:
            return False

        self.turtle_x, self.turtle_y = p
        dx, dy = direction
        self.turtle_line = line
        self.turtle_path = "line"
        self.turtle_angle = math.degrees(math.atan2(dy, dx))
        self.message = "Path changed."
        self.message_colour = BLUE
        return True

    def horizontal_zero_line(self):
        """Return the newest student line that is exactly y = 0, if one exists."""
        for line in reversed(self.lines):
            if abs(line.A) < 1e-9 and abs(line.C) < 1e-9 and abs(line.B) > 1e-9:
                return line
        return None

    def move_turtle(self, dt, keys):
        if self.falling:
            return

        amount = TURTLE_SPEED * dt
        old_x, old_y = self.turtle_x, self.turtle_y

        pressed = []
        if keys[pygame.K_UP]:
            pressed.append("up")
        if keys[pygame.K_RIGHT]:
            pressed.append("right")
        if keys[pygame.K_DOWN]:
            pressed.append("down")
        if keys[pygame.K_LEFT]:
            pressed.append("left")

        if not pressed:
            return

        # Holding an arrow does not switch paths automatically.
        # A switch requires a fresh KEYDOWN while touching an intersection.
        # The player can release and press the same arrow again, or press a
        # different arrow, to choose the intersecting path.

        if self.turtle_path == "start":
            # Start ledge is horizontal: LEFT/RIGHT only.
            if "right" in pressed:
                move_sign = 1
            elif "left" in pressed:
                move_sign = -1
            else:
                return

            self.turtle_x += move_sign * amount
            self.turtle_angle = 0 if move_sign > 0 else 180

            if self.turtle_x < START_X1:
                self.turtle_x = START_X1

            if self.turtle_x > START_X2:
                zero_line = self.horizontal_zero_line()
                if zero_line is not None and move_sign > 0:
                    self.turtle_path = "line"
                    self.turtle_line = zero_line
                    self.turtle_y = 0.0
                    self.turtle_angle = 0
                else:
                    self.turtle_x = START_X2 + 0.03
                    self.turtle_path = None
                    self.falling = True
                    self.fall_old_y = self.turtle_y
            return

        if self.turtle_path == "finish":
            if "right" in pressed:
                move_sign = 1
            elif "left" in pressed:
                move_sign = -1
            else:
                return

            self.turtle_x += move_sign * amount
            self.turtle_angle = 0 if move_sign > 0 else 180
            self.turtle_x = max(FINISH_X1, min(FINISH_X2, self.turtle_x))
            return

        if self.turtle_line is not None:
            direction = None
            for key_name in pressed:
                direction = self.direction_for_key(self.turtle_line, key_name)
                if direction is not None:
                    break

            if direction is None:
                return

            dx, dy = direction
            self.turtle_x += dx * amount
            self.turtle_y += dy * amount
            self.turtle_angle = math.degrees(math.atan2(dy, dx))
            self.check_line_arrival(old_x, old_y)

    def check_line_arrival(self, old_x, old_y):
        # A horizontal y=0 path enters the safe zone without needing to cross y=0.
        if (
            self.turtle_line is not None
            and abs(self.turtle_y - PLATFORM_Y) < 1e-6
            and self.turtle_x >= FINISH_X1
        ):
            self.turtle_x = min(self.turtle_x, FINISH_X2)
            self.turtle_y = PLATFORM_Y
            self.turtle_path = "finish"
            self.turtle_line = None
            self.turtle_angle = 0
            return

        # Any other line that crosses y=0 inside the safe zone lands there.
        if (
            self.turtle_line is not None
            and (old_y - PLATFORM_Y) * (self.turtle_y - PLATFORM_Y) <= 0
            and abs(self.turtle_y - old_y) > 1e-8
        ):
            t = (PLATFORM_Y - old_y) / (self.turtle_y - old_y)
            cross_x = old_x + t * (self.turtle_x - old_x)

            if FINISH_X1 <= cross_x <= FINISH_X2:
                self.turtle_x = cross_x
                self.turtle_y = PLATFORM_Y
                self.turtle_path = "finish"
                self.turtle_line = None
                self.turtle_angle = 0
                return

        # Touching any graph border while on a student line ends the attempt.
        # The physical START and SAFE ZONE are handled separately above.
        if (
            self.turtle_x <= MIN_COORD
            or self.turtle_x >= MAX_COORD
            or self.turtle_y <= MIN_COORD
            or self.turtle_y >= MAX_COORD
        ):
            self.turtle_x = max(MIN_COORD, min(MAX_COORD, self.turtle_x))
            self.turtle_y = max(MIN_COORD, min(MAX_COORD, self.turtle_y))
            self.game_over("The turtle left the game world.")

    def update_fall(self, dt):
        if not self.falling:
            return

        old_y = self.turtle_y
        new_y = self.turtle_y - FALL_SPEED * dt

        # Find the highest student line crossed during this downward step.
        best = None
        for line in self.lines:
            if line.vertical:
                continue
            ly = line.y_at(self.turtle_x)
            if ly is None:
                continue
            if new_y - LAND_TOL <= ly <= old_y + LAND_TOL:
                if best is None or ly > best[0]:
                    best = (ly, line)

        # Physical ledges can also catch the turtle.
        if START_X1 <= self.turtle_x <= START_X2 and new_y <= PLATFORM_Y <= old_y:
            if best is None or PLATFORM_Y > best[0]:
                best = (PLATFORM_Y, "start")

        if FINISH_X1 <= self.turtle_x <= FINISH_X2 and new_y <= PLATFORM_Y <= old_y:
            if best is None or PLATFORM_Y > best[0]:
                best = (PLATFORM_Y, "finish")

        if best is not None:
            self.turtle_y = best[0]
            self.falling = False
            if best[1] == "start":
                self.turtle_path = "start"
                self.turtle_line = None
                self.turtle_angle = 0
            elif best[1] == "finish":
                self.turtle_path = "finish"
                self.turtle_line = None
                self.turtle_angle = 0
            else:
                self.turtle_path = "line"
                self.turtle_line = best[1]

                # Match the turtle's rotation to the slope of the line.
                # Point it generally to the right after landing so the same
                # geometric line never appears rotated by an extra 180 degrees.
                dx, dy = best[1].dx, best[1].dy
                if dx < 0:
                    dx, dy = -dx, -dy
                self.turtle_angle = math.degrees(math.atan2(dy, dx))
            self.message = "The turtle landed on a path!"
            self.message_colour = BLUE
            return

        self.turtle_y = new_y
        self.turtle_angle = -90

        if self.turtle_y < MIN_COORD - 1:
            self.game_over("The turtle fell out of the game world.")

    def check_hawk_collision(self):
        if self.state != "playing":
            return
        for hawk in self.hawks:
            hx, hy = hawk.position()
            if math.dist((hx, hy), (self.turtle_x, self.turtle_y)) <= HAWK_RADIUS + TURTLE_RADIUS:
                self.game_over("A hawk caught the turtle!")
                return

    def check_finish(self):
        if self.state != "playing":
            return
        if self.turtle_path == "finish" and self.turtle_x >= FINISH_X1 + 1.0:
            if self.level == len(HAWK_COUNTS) - 1:
                self.state = "won"
            else:
                self.state = "level_complete"

    def game_over(self, reason):
        self.state = "game_over"
        self.message = reason
        self.message_colour = RED

    def update(self, dt):
        if self.state != "playing":
            return

        for hawk in self.hawks:
            hawk.update(dt, self.circle_radius)

        keys = pygame.key.get_pressed()
        if not self.line_input.active and not self.circle_input.active:
            self.move_turtle(dt, keys)
        else:
            self.vertical_move_key = None
        self.update_fall(dt)
        self.check_hawk_collision()
        self.check_finish()

    def handle_event(self, event):
        if self.state == "game_over":
            if self.retry_button.clicked(event):
                self.start_level()
            return

        if self.state == "level_complete":
            if self.next_button.clicked(event):
                self.level += 1
                self.start_level()
            return

        if self.state == "won":
            if self.restart_button.clicked(event):
                self.level = 0
                self.start_level()
            return

        # Switch only on a NEW arrow-key press while touching a crossing.
        if (
            event.type == pygame.KEYDOWN
            and not self.line_input.active
            and not self.circle_input.active
        ):
            key_names = {
                pygame.K_UP: "up",
                pygame.K_RIGHT: "right",
                pygame.K_DOWN: "down",
                pygame.K_LEFT: "left",
            }
            key_name = key_names.get(event.key)
            if key_name is not None:
                self.switch_to_line(key_name)

        line_submit, line_empty_backspace = self.line_input.handle_event(event)
        circle_submit, circle_empty_backspace = self.circle_input.handle_event(event)

        if line_submit:
            self.add_line()
        if line_empty_backspace:
            self.delete_latest_line()

        if circle_submit:
            self.create_circle()
        if circle_empty_backspace:
            self.remove_circle()

    # -------------------- DRAWING --------------------
    def draw_grid(self):
        pygame.draw.rect(
            SCREEN,
            WHITE,
            (GRAPH_LEFT, GRAPH_TOP, GRAPH_SIZE, GRAPH_SIZE),
        )

        for n in range(MIN_COORD, MAX_COORD + 1):
            sx, _ = graph_to_screen(n, 0)
            _, sy = graph_to_screen(0, n)
            pygame.draw.line(SCREEN, GRID, (sx, GRAPH_TOP), (sx, GRAPH_TOP + GRAPH_SIZE), 1)
            pygame.draw.line(SCREEN, GRID, (GRAPH_LEFT, sy), (GRAPH_LEFT + GRAPH_SIZE, sy), 1)

        x0, y0 = graph_to_screen(0, 0)
        pygame.draw.line(SCREEN, AXIS, (GRAPH_LEFT, y0), (GRAPH_LEFT + GRAPH_SIZE, y0), 2)
        pygame.draw.line(SCREEN, AXIS, (x0, GRAPH_TOP), (x0, GRAPH_TOP + GRAPH_SIZE), 2)

        # Labels every 5 units.
        for n in range(MIN_COORD, MAX_COORD + 1, 5):
            if n == 0:
                continue
            sx, sy0 = graph_to_screen(n, 0)
            label = TINY_FONT.render(str(n), True, GREY)
            SCREEN.blit(label, (sx - label.get_width() // 2, sy0 + 4))

            sx0, sy = graph_to_screen(0, n)
            label = TINY_FONT.render(str(n), True, GREY)
            SCREEN.blit(label, (sx0 + 5, sy - label.get_height() // 2))

        pygame.draw.rect(
            SCREEN,
            BLACK,
            (GRAPH_LEFT, GRAPH_TOP, GRAPH_SIZE, GRAPH_SIZE),
            2,
        )

    def draw_platforms(self):
        # Start ledge
        s1 = graph_to_screen(START_X1, PLATFORM_Y)
        s2 = graph_to_screen(START_X2, PLATFORM_Y)
        pygame.draw.line(SCREEN, BROWN, s1, s2, 10)
        label = SMALL_FONT.render("START", True, BROWN)
        SCREEN.blit(label, (s1[0], s1[1] + 10))

        # Finish ledge
        f1 = graph_to_screen(FINISH_X1, PLATFORM_Y)
        f2 = graph_to_screen(FINISH_X2, PLATFORM_Y)
        pygame.draw.line(SCREEN, GREEN, f1, f2, 10)
        label = SMALL_FONT.render("SAFE ZONE", True, DARK_GREEN)
        SCREEN.blit(label, (f1[0], f1[1] + 10))

    def draw_student_lines(self):
        highlighted_line, highlighted_point = self.near_intersection()

        for line in self.lines:
            pts = line.visible_endpoints()
            if len(pts) != 2:
                continue
            p1 = graph_to_screen(*pts[0])
            p2 = graph_to_screen(*pts[1])

            colour = PURPLE
            width = 3
            if line is highlighted_line:
                colour = YELLOW
                width = 6

            pygame.draw.line(SCREEN, colour, p1, p2, width)

        if highlighted_point is not None:
            sx, sy = graph_to_screen(*highlighted_point)
            pygame.draw.circle(SCREEN, YELLOW, (sx, sy), 9, 3)

    def draw_circle(self):
        if self.circle_radius is None:
            return
        cx, cy = graph_to_screen(0, 0)
        radius_px = int(self.circle_radius * SCALE)
        if radius_px > 0:
            pygame.draw.circle(SCREEN, BLUE, (cx, cy), radius_px, 4)

    def draw_turtle(self):
        sx, sy = graph_to_screen(self.turtle_x, self.turtle_y)

        # Placeholder turtle: a rectangular surface rotated to its path angle.
        w = max(12, int(1.25 * SCALE))
        h = max(9, int(0.75 * SCALE))
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.rect(surf, GREEN, (0, 0, w, h), border_radius=4)
        pygame.draw.rect(surf, BLACK, (0, 0, w, h), 2, border_radius=4)

        # Tiny "head" on the right side makes orientation visible.
        pygame.draw.circle(surf, DARK_GREEN, (w - 2, h // 2), max(3, h // 4))

        rotated = pygame.transform.rotate(surf, self.turtle_angle)
        rect = rotated.get_rect(center=(sx, sy))
        SCREEN.blit(rotated, rect)

    def draw_panel(self):
        pygame.draw.rect(SCREEN, LIGHT_PANEL, (800, 0, 400, HEIGHT))

        SCREEN.blit(TITLE_FONT.render("Turtle Line Escape", True, BLACK), (PANEL_LEFT, 25))
        SCREEN.blit(
            FONT.render(
                f"Level {self.level + 1} of 10   •   {HAWK_COUNTS[self.level]} hawks",
                True,
                BLUE,
            ),
            (PANEL_LEFT, 68),
        )

        SCREEN.blit(FONT.render("Create a linear path", True, BLACK), (PANEL_LEFT, 135))
        self.line_input.draw()
        SCREEN.blit(
            SMALL_FONT.render("Use: y=mx+b, y=b, or x=a", True, GREY),
            (PANEL_LEFT, 235),
        )
        SCREEN.blit(
            SMALL_FONT.render("Empty box + Backspace = erase newest line", True, GREY),
            (PANEL_LEFT, 260),
        )

        SCREEN.blit(FONT.render("Trap hawks with a circle", True, BLACK), (PANEL_LEFT, 300))
        SCREEN.blit(FONT.render("x² + y² =", True, BLACK), (PANEL_LEFT, 357))
        # Compact box placed close to x² + y² =
        self.circle_input.rect.x = PANEL_LEFT + 88
        self.circle_input.rect.width = 90
        self.circle_input.draw()
        SCREEN.blit(
            SMALL_FONT.render("Enter r². Empty box + Backspace removes circle.", True, GREY),
            (PANEL_LEFT, 405),
        )

        SCREEN.blit(FONT.render("Controls", True, BLACK), (PANEL_LEFT, 455))
        controls = [
            "Arrows move along the current path",
            "At a crossing: release + press to switch",
            "Changing arrow direction can also switch",
            "Horizontal: ←/→   Vertical: ↑/↓",
            "Enter   Submit the active input",
        ]
        yy = 490
        for text in controls:
            SCREEN.blit(SMALL_FONT.render(text, True, BLACK), (PANEL_LEFT, yy))
            yy += 27

        SCREEN.blit(FONT.render("Status", True, BLACK), (PANEL_LEFT, 625))
        yy = 658
        for line in wrap_text(self.message, SMALL_FONT, 345):
            SCREEN.blit(SMALL_FONT.render(line, True, self.message_colour), (PANEL_LEFT, yy))
            yy += 23

        if self.state == "game_over":
            SCREEN.blit(BIG_FONT.render("GAME OVER", True, RED), (PANEL_LEFT, 690))
            self.retry_button.draw()
        elif self.state == "level_complete":
            SCREEN.blit(BIG_FONT.render("LEVEL COMPLETE!", True, DARK_GREEN), (PANEL_LEFT, 685))
            next_count = HAWK_COUNTS[self.level + 1]
            SCREEN.blit(
                SMALL_FONT.render(f"Next level: {next_count} hawks", True, BLACK),
                (PANEL_LEFT, 725),
            )
            self.next_button.draw()
        elif self.state == "won":
            SCREEN.blit(BIG_FONT.render("GOOD JOB!", True, DARK_GREEN), (PANEL_LEFT, 685))
            SCREEN.blit(
                SMALL_FONT.render("You completed all 10 levels!", True, BLACK),
                (PANEL_LEFT, 725),
            )
            self.restart_button.draw()

    def draw(self):
        SCREEN.fill(WHITE)
        self.draw_grid()
        self.draw_platforms()
        self.draw_student_lines()
        self.draw_circle()

        for hawk in self.hawks:
            hawk.draw()

        self.draw_turtle()
        self.draw_panel()


async def main():
    game = Game()
    running = True

    while running:
        dt = min(CLOCK.tick(60) / 1000.0, 0.05)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            else:
                game.handle_event(event)

        game.update(dt)
        game.draw()
        pygame.display.flip()

        # Give control back to the browser each frame.
        await asyncio.sleep(0)

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
