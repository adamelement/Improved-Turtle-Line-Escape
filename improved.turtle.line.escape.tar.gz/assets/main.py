import asyncio
import math
import random
import re

import pygame

pygame.init()

# -------------------- WINDOW / GRAPH --------------------
WIDTH, HEIGHT = 1200, 850
GRAPH_SIZE = 760
GRAPH_LEFT = 25
GRAPH_TOP = 55
PANEL_LEFT = 820

MIN_COORD = -20
MAX_COORD = 20
SCALE = GRAPH_SIZE / (MAX_COORD - MIN_COORD)

SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Turtle Line Escape")
CLOCK = pygame.time.Clock()

FONT = pygame.font.SysFont("arial", 22)
SMALL_FONT = pygame.font.SysFont("arial", 17)
TINY_FONT = pygame.font.SysFont("arial", 14)
BIG_FONT = pygame.font.SysFont("arial", 34, bold=True)
TITLE_FONT = pygame.font.SysFont("arial", 27, bold=True)

WHITE = (255, 255, 255)
BLACK = (25, 25, 25)
GRID = (224, 227, 232)
AXIS = (90, 95, 105)
BLUE = (45, 105, 210)
RED = (210, 65, 65)
GREEN = (30, 145, 75)
DARK_GREEN = (15, 105, 55)
ORANGE = (235, 145, 40)
PURPLE = (125, 80, 190)
BROWN = (130, 90, 55)
GREY = (115, 120, 130)
LIGHT_PANEL = (247, 248, 250)
YELLOW = (245, 205, 55)
OBSTACLE_RED = (175, 55, 45)


HAWK_COUNTS = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]

# Physical platforms. Their sides and heights are randomized each round.
LEFT_LEDGE = (MIN_COORD, -15.0)
RIGHT_LEDGE = (15.0, MAX_COORD)
PLATFORM_MIN_Y = -15
PLATFORM_MAX_Y = 15
MIN_PLATFORM_HEIGHT_DIFFERENCE = 4

# Each round has one obstacle, with a 50% chance of a second.
MIN_OBSTACLES = 1
MAX_OBSTACLES = 2

TURTLE_SPEED = 4.2       # graph units / second
FALL_SPEED = 8.0
TURTLE_RADIUS = 0.55
HAWK_RADIUS = 0.38
HAWK_DRAW_WIDTH = 56
HAWK_DRAW_HEIGHT = 36
# The drawing faces right and its beak is close to the right edge.
HAWK_BEAK_REACH = (HAWK_DRAW_WIDTH * 0.48) / SCALE
INTERSECTION_TOL = 0.85
INTERSECTION_GRACE = 0.0
LAND_TOL = 0.18
PATH_CLEARANCE = TURTLE_RADIUS + 0.08


def distance_to_segment(px, py, x1, y1, x2, y2):
    """Shortest distance from a point to a line segment."""
    vx, vy = x2 - x1, y2 - y1
    length_sq = vx * vx + vy * vy
    if length_sq == 0:
        return math.hypot(px - x1, py - y1)
    t = max(0.0, min(1.0, ((px - x1) * vx + (py - y1) * vy) / length_sq))
    return math.hypot(px - (x1 + t * vx), py - (y1 + t * vy))


def point_in_polygon(px, py, polygon):
    """Ray-casting test for a point inside a polygon."""
    inside = False
    j = len(polygon) - 1
    for i, (xi, yi) in enumerate(polygon):
        xj, yj = polygon[j]
        if (yi > py) != (yj > py):
            intersection_x = (xj - xi) * (py - yi) / (yj - yi) + xi
            if px < intersection_x:
                inside = not inside
        j = i
    return inside


# -------------------- HELPERS --------------------
def graph_to_screen(gx, gy):
    sx = GRAPH_LEFT + (gx - MIN_COORD) * SCALE
    sy = GRAPH_TOP + (MAX_COORD - gy) * SCALE
    return int(round(sx)), int(round(sy))


def screen_inside_graph(sx, sy):
    return (
        GRAPH_LEFT <= sx <= GRAPH_LEFT + GRAPH_SIZE
        and GRAPH_TOP <= sy <= GRAPH_TOP + GRAPH_SIZE
    )


def clean_math_text(text):
    """Make equation input easier to parse."""
    return text.strip().lower().replace(" ", "").replace("−", "-")


def parse_number(text):
    """Convert a simple signed decimal/fraction to a float."""
    text = text.strip()
    if text in ("", "+"):
        return 1.0
    if text == "-":
        return -1.0

    if "/" in text:
        if text.count("/") != 1:
            raise ValueError("Use a simple number or fraction.")
        numerator, denominator = text.split("/")
        value = float(numerator) / float(denominator)
        return value

    return float(text)


def parse_linear_equation(text):
    """
    Accept only beginner-friendly linear forms:
        y = mx + b
        y = b
        x = a

    Examples:
        y=2x+5
        y=-x+3
        y=0.5x-4
        y=3/2x+1
        y=6
        x=-4
    """
    original = text.strip()
    text = clean_math_text(text)

    if text.count("=") != 1:
        raise ValueError("Use one equals sign.")

    left, right = text.split("=")

    if left not in ("x", "y") or not right:
        raise ValueError("Use y = mx + b, y = b, or x = a.")

    # Vertical line: x = a  ->  x - a = 0
    if left == "x":
        if "x" in right or "y" in right:
            raise ValueError("For a vertical line, use x = a. Example: x = 4.")
        try:
            a = parse_number(right)
        except (ValueError, ZeroDivisionError):
            raise ValueError("For a vertical line, use x = a. Example: x = 4.")
        return Line(1.0, 0.0, -a, original)

    # Horizontal line: y = b
    if "x" not in right:
        if "y" in right:
            raise ValueError("Use y = mx + b, y = b, or x = a.")
        try:
            b = parse_number(right)
        except (ValueError, ZeroDivisionError):
            raise ValueError("For a horizontal line, use y = b. Example: y = 5.")
        return Line(0.0, 1.0, -b, original)

    # Sloped line: y = mx + b
    if right.count("x") != 1 or "y" in right:
        raise ValueError("Use y = mx + b. Example: y = 2x + 5.")

    x_pos = right.index("x")
    m_text = right[:x_pos]
    b_text = right[x_pos + 1:]

    try:
        m = parse_number(m_text)

        if b_text == "":
            b = 0.0
        else:
            # The part after x must begin with + or -.
            if b_text[0] not in "+-":
                raise ValueError
            b = parse_number(b_text)
    except (ValueError, ZeroDivisionError):
        raise ValueError(
            "Use y = mx + b. Examples: y = 2x + 5, y = -x - 3, y = 0.5x."
        )

    # y = mx + b  ->  mx - y + b = 0
    return Line(m, -1.0, b, original)


def point_on_segment(px, py, x1, y1, x2, y2, tol=0.25):
    cross = abs((px - x1) * (y2 - y1) - (py - y1) * (x2 - x1))
    length = math.hypot(x2 - x1, y2 - y1)
    if length == 0 or cross / length > tol:
        return False
    dot = (px - x1) * (px - x2) + (py - y1) * (py - y2)
    return dot <= tol


def wrap_text(text, font, max_width):
    words = text.split()
    lines, current = [], ""
    for word in words:
        trial = word if not current else current + " " + word
        if font.size(trial)[0] <= max_width:
            current = trial
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


# -------------------- LINE OBJECT --------------------
class Line:
    def __init__(self, A, B, C, label=""):
        self.A = A
        self.B = B
        self.C = C
        self.label = label
        # A direction vector along Ax + By + C = 0 is (B, -A)
        length = math.hypot(B, -A)
        self.dx = B / length
        self.dy = -A / length

    @property
    def vertical(self):
        return abs(self.B) < 1e-9

    def signed_value(self, px, py):
        return self.A * px + self.B * py + self.C

    def intersection(self, other):
        det = self.A * other.B - other.A * self.B
        if abs(det) < 1e-9:
            return None
        ix = (self.B * other.C - other.B * self.C) / det
        iy = (self.C * other.A - other.C * self.A) / det
        return ix, iy

    def visible_endpoints(self):
        pts = []

        if abs(self.B) > 1e-9:
            for gx in (MIN_COORD, MAX_COORD):
                gy = -(self.A * gx + self.C) / self.B
                if MIN_COORD - 1e-8 <= gy <= MAX_COORD + 1e-8:
                    pts.append((gx, gy))

        if abs(self.A) > 1e-9:
            for gy in (MIN_COORD, MAX_COORD):
                gx = -(self.B * gy + self.C) / self.A
                if MIN_COORD - 1e-8 <= gx <= MAX_COORD + 1e-8:
                    pts.append((gx, gy))

        unique = []
        for p in pts:
            if not any(math.dist(p, q) < 1e-6 for q in unique):
                unique.append(p)
        return unique[:2]

    def y_at(self, gx):
        if abs(self.B) < 1e-9:
            return None
        return -(self.A * gx + self.C) / self.B


# -------------------- UI --------------------
class InputBox:
    def __init__(self, x0, y0, w, h):
        self.rect = pygame.Rect(x0, y0, w, h)
        self.text = ""
        self.active = False

    def handle_event(self, event):
        submitted = False
        empty_backspace = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            self.active = self.rect.collidepoint(event.pos)

        if event.type == pygame.KEYDOWN and self.active:
            if event.key == pygame.K_RETURN:
                submitted = True
            elif event.key == pygame.K_BACKSPACE:
                if self.text:
                    self.text = self.text[:-1]
                else:
                    empty_backspace = True
            elif event.unicode and event.unicode.isprintable():
                self.text += event.unicode

        return submitted, empty_backspace

    def draw(self):
        colour = BLUE if self.active else GREY
        pygame.draw.rect(SCREEN, WHITE, self.rect)
        pygame.draw.rect(SCREEN, colour, self.rect, 2, border_radius=5)
        txt = FONT.render(self.text, True, BLACK)
        SCREEN.blit(txt, (self.rect.x + 8, self.rect.y + 7))


class Button:
    def __init__(self, x0, y0, w, h, text):
        self.rect = pygame.Rect(x0, y0, w, h)
        self.text = text

    def clicked(self, event):
        return event.type == pygame.MOUSEBUTTONDOWN and self.rect.collidepoint(event.pos)

    def draw(self):
        pygame.draw.rect(SCREEN, WHITE, self.rect, border_radius=7)
        pygame.draw.rect(SCREEN, BLUE, self.rect, 2, border_radius=7)
        surf = FONT.render(self.text, True, BLUE)
        SCREEN.blit(
            surf,
            (
                self.rect.centerx - surf.get_width() // 2,
                self.rect.centery - surf.get_height() // 2,
            ),
        )


# -------------------- HAWKS --------------------
class Hawk:
    def __init__(self, line, t, direction, speed):
        self.line = line
        self.t = t
        self.direction = direction
        self.speed = speed
        self.allowed_inside = None

    def position(self):
        # point nearest origin on line, plus t * direction vector
        denom = self.line.A ** 2 + self.line.B ** 2
        bx = -self.line.A * self.line.C / denom
        by = -self.line.B * self.line.C / denom
        return bx + self.line.dx * self.t, by + self.line.dy * self.t

    def update(self, dt, circle_radius):
        old_t = self.t
        old_x, old_y = self.position()

        self.t += self.direction * self.speed * dt
        nx, ny = self.position()

        # Reverse when the forward tip of the beak reaches a graph boundary.
        forward_x = self.line.dx * self.direction
        forward_y = self.line.dy * self.direction
        beak_x = nx + forward_x * HAWK_BEAK_REACH
        beak_y = ny + forward_y * HAWK_BEAK_REACH
        if not (MIN_COORD <= beak_x <= MAX_COORD and MIN_COORD <= beak_y <= MAX_COORD):
            self.t = old_t
            self.direction *= -1
            return

        # Circle is a barrier: use the forward tip of the beak rather than the
        # hawk's centre, so the head does not visibly protrude through it.
        if circle_radius is not None and self.allowed_inside is not None:
            beak_x = nx + forward_x * HAWK_BEAK_REACH
            beak_y = ny + forward_y * HAWK_BEAK_REACH
            inside_next = math.hypot(beak_x, beak_y) <= circle_radius
            if inside_next != self.allowed_inside:
                self.t = old_t
                self.direction *= -1

    def make_surface(self):
        """Create the original small, right-facing brown-and-cream hawk."""
        w, h = HAWK_DRAW_WIDTH, HAWK_DRAW_HEIGHT
        surf = pygame.Surface((w, h), pygame.SRCALPHA)

        outline = (55, 38, 27)
        dark_brown = (91, 57, 34)
        brown = (132, 84, 45)
        light_brown = (181, 128, 70)
        cream = (226, 210, 164)
        beak_yellow = (224, 167, 40)

        def p(x, y):
            return round(x * w), round(y * h)

        # Brown tail and feathered wings.
        pygame.draw.polygon(
            surf, dark_brown,
            [p(.33, .40), p(.05, .28), p(.18, .50), p(.05, .72), p(.33, .60)],
        )

        upper_wing = [
            p(.49, .48), p(.42, .27), p(.20, .05), p(.24, .25),
            p(.08, .13), p(.17, .35), p(.02, .34), p(.24, .53),
        ]
        lower_wing = [
            p(.49, .52), p(.42, .73), p(.20, .95), p(.24, .75),
            p(.08, .87), p(.17, .65), p(.02, .66), p(.24, .47),
        ]
        pygame.draw.polygon(surf, brown, upper_wing)
        pygame.draw.polygon(surf, brown, lower_wing)
        pygame.draw.lines(surf, outline, True, upper_wing, 1)
        pygame.draw.lines(surf, outline, True, lower_wing, 1)
        pygame.draw.line(surf, light_brown, p(.18, .24), p(.40, .42), 2)
        pygame.draw.line(surf, light_brown, p(.18, .76), p(.40, .58), 2)

        # Dark-brown body with a pale chest.
        body = pygame.Rect(round(w * .30), round(h * .34),
                           round(w * .43), round(h * .32))
        pygame.draw.ellipse(surf, outline, body)
        pygame.draw.ellipse(surf, dark_brown, body.inflate(-3, -3))
        chest = pygame.Rect(round(w * .53), round(h * .40),
                            round(w * .20), round(h * .20))
        pygame.draw.ellipse(surf, cream, chest)

        head = p(.72, .50)
        head_radius = max(3, round(min(w, h) * .16))
        pygame.draw.circle(surf, outline, head, head_radius + 1)
        pygame.draw.circle(surf, cream, head, head_radius)
        pygame.draw.polygon(
            surf, beak_yellow,
            [p(.80, .44), p(.98, .50), p(.81, .58), p(.85, .51)],
        )
        pygame.draw.circle(surf, (15, 15, 12), p(.75, .44), 1)
        return surf

    def draw(self):
        gx, gy = self.position()
        sx, sy = graph_to_screen(gx, gy)

        # The base drawing faces right. The graph's y direction is opposite
        # the screen's y direction, so this angle makes the beak face along
        # the hawk's current path and flips naturally after every bounce.
        vx = self.line.dx * self.direction
        vy = self.line.dy * self.direction
        angle = math.degrees(math.atan2(vy, vx))
        image = pygame.transform.rotozoom(self.make_surface(), angle, 1.0)
        SCREEN.blit(image, image.get_rect(center=(sx, sy)))


# -------------------- GAME --------------------
class Game:
    def __init__(self):
        self.line_input = InputBox(PANEL_LEFT, 165, 345, 43)
        self.circle_input = InputBox(PANEL_LEFT, 330, 345, 43)
        self.next_button = Button(PANEL_LEFT, 770, 160, 46, "Next Level")
        self.retry_button = Button(PANEL_LEFT, 770, 140, 46, "Try Again")
        self.restart_button = Button(PANEL_LEFT, 770, 170, 46, "Restart Game")

        self.level = 0
        self.state = "playing"
        self.level_scores = []
        self.last_level_score = None
        self.dance_time = 0.0
        self.start_level()

    def start_level(self):
        self.state = "playing"
        self.lines = []
        self.circle_radius = None
        self.line_input.text = ""
        self.circle_input.text = ""
        self.message = "Create paths, avoid outlined obstacles, and trap the hawks."
        self.message_colour = BLACK

        self.randomize_platforms()
        self.obstacles = self.make_obstacles(random.randint(MIN_OBSTACLES, MAX_OBSTACLES))

        # Turtle starts one unit in from the outside end of its ledge.
        if self.start_side == "left":
            self.turtle_x = self.start_x1 + 1.0
            self.turtle_angle = 0.0
        else:
            self.turtle_x = self.start_x2 - 1.0
            self.turtle_angle = 180.0
        self.turtle_y = self.start_y
        self.actual_distance = 0.0
        self.dance_time = 0.0
        self.turtle_path = "start"
        self.turtle_line = None
        self.falling = False
        self.fall_old_y = self.turtle_y
        self.fall_facing_angle = self.turtle_angle
        self.vertical_move_key = None
        self.cached_switch_line = None
        self.cached_switch_point = None
        self.switch_grace = 0.0

        self.hawks = self.make_hawks(HAWK_COUNTS[self.level])
        self.minimum_distance = self.calculate_minimum_distance()

    def randomize_platforms(self):
        """Put START and SAFE ZONE on opposite, randomly selected sides."""
        self.start_side = random.choice(("left", "right"))
        self.finish_side = "right" if self.start_side == "left" else "left"
        self.start_y = float(random.randint(PLATFORM_MIN_Y, PLATFORM_MAX_Y))
        choices = [y for y in range(PLATFORM_MIN_Y, PLATFORM_MAX_Y + 1)
                   if abs(y - self.start_y) >= MIN_PLATFORM_HEIGHT_DIFFERENCE]
        self.finish_y = float(random.choice(choices))
        self.start_x1, self.start_x2 = LEFT_LEDGE if self.start_side == "left" else RIGHT_LEDGE
        self.finish_x1, self.finish_x2 = LEFT_LEDGE if self.finish_side == "left" else RIGHT_LEDGE

    def make_obstacles(self, count):
        """Create one compact jagged hazard and, sometimes, a separate second."""
        obstacle_data = []

        def create_blob(cx, cy, rx, ry):
            points = []
            point_count = random.randint(7, 10)
            angle_offset = random.uniform(0, 2 * math.pi)
            for i in range(point_count):
                angle = angle_offset + 2 * math.pi * i / point_count
                jag = random.uniform(0.72, 1.22)
                points.append((cx + math.cos(angle) * rx * jag,
                               cy + math.sin(angle) * ry * jag))
            return points

        # The first obstacle is centred at exactly the same y-value as START.
        rx = random.uniform(2.3, 3.7)
        ry = random.uniform(2.3, 3.7)
        cx = random.uniform(-8.5, 8.5)
        cy = self.start_y
        first_blob = create_blob(cx, cy, rx, ry)
        obstacle_data.append((first_blob, cx, cy, max(rx, ry)))

        # The optional second obstacle is central, separated, and clear of edges.
        if count == 2:
            for _ in range(500):
                rx2 = random.uniform(2.0, 3.4)
                ry2 = random.uniform(2.0, 3.4)
                cx2 = random.uniform(-10.5 + rx2, 10.5 - rx2)
                cy2 = random.uniform(-15.5 + ry2, 15.5 - ry2)
                if math.hypot(cx2 - cx, cy2 - cy) >= max(rx, ry) + max(rx2, ry2) + 2.0:
                    obstacle_data.append((create_blob(cx2, cy2, rx2, ry2),
                                          cx2, cy2, max(rx2, ry2)))
                    break

        return [item[0] for item in obstacle_data]

    def point_clear_of_obstacles(self, point, clearance=PATH_CLEARANCE):
        px, py = point
        for polygon in self.obstacles:
            if point_in_polygon(px, py, polygon):
                return False
            for i, (x1, y1) in enumerate(polygon):
                x2, y2 = polygon[(i + 1) % len(polygon)]
                if distance_to_segment(px, py, x1, y1, x2, y2) < clearance:
                    return False
        return True

    def route_segment_is_clear(self, start, end):
        """Check a proposed shortest-path segment at fine intervals."""
        distance = math.dist(start, end)
        steps = max(2, int(math.ceil(distance / 0.12)))
        for i in range(1, steps):
            t = i / steps
            point = (start[0] + (end[0] - start[0]) * t,
                     start[1] + (end[1] - start[1]) * t)
            if not self.point_clear_of_obstacles(point):
                return False
        return True

    def calculate_minimum_distance(self):
        """Approximate the shortest safe route with a visibility graph."""
        start = (self.turtle_x, self.turtle_y)
        # The round completes at the inner edge of the SAFE ZONE.
        goal_x = self.finish_x1 if self.finish_side == "right" else self.finish_x2
        goal = (goal_x, self.finish_y)
        nodes = [start, goal]

        # Offset each corner away from its obstacle by the turtle's clearance.
        for polygon in self.obstacles:
            cx = sum(x for x, _ in polygon) / len(polygon)
            cy = sum(y for _, y in polygon) / len(polygon)
            for x, y in polygon:
                vx, vy = x - cx, y - cy
                length = math.hypot(vx, vy) or 1.0
                candidate = (x + vx / length * PATH_CLEARANCE * 1.35,
                             y + vy / length * PATH_CLEARANCE * 1.35)
                if (MIN_COORD < candidate[0] < MAX_COORD
                        and MIN_COORD < candidate[1] < MAX_COORD
                        and self.point_clear_of_obstacles(candidate, PATH_CLEARANCE * 0.98)):
                    nodes.append(candidate)

        graph = [[] for _ in nodes]
        for i in range(len(nodes)):
            for j in range(i + 1, len(nodes)):
                if self.route_segment_is_clear(nodes[i], nodes[j]):
                    weight = math.dist(nodes[i], nodes[j])
                    graph[i].append((j, weight))
                    graph[j].append((i, weight))

        distances = [float("inf")] * len(nodes)
        visited = [False] * len(nodes)
        distances[0] = 0.0
        for _ in nodes:
            current = min((i for i in range(len(nodes)) if not visited[i]),
                          key=lambda i: distances[i], default=None)
            if current is None or math.isinf(distances[current]):
                break
            if current == 1:
                break
            visited[current] = True
            for neighbour, weight in graph[current]:
                distances[neighbour] = min(distances[neighbour],
                                           distances[current] + weight)

        # A route around compact central obstacles should always exist. This
        # conservative fallback prevents scoring from failing unexpectedly.
        if math.isinf(distances[1]):
            return math.dist(start, goal)
        return distances[1]

    def finish_level_score(self):
        travelled = max(self.actual_distance, self.minimum_distance)
        self.last_level_score = max(0.0, min(100.0,
                                    100.0 * self.minimum_distance / travelled))
        if len(self.level_scores) == self.level:
            self.level_scores.append(self.last_level_score)
        else:
            self.level_scores[self.level] = self.last_level_score
        self.message = "The turtle reached the safe zone!"
        self.message_colour = DARK_GREEN
        self.dance_time = 0.0

    def make_hawks(self, count):
        hawks = []

        # Every hawk line passes within this many graph units of the origin.
        # This keeps central capture opportunities possible without forcing
        # all hawks through the exact origin.
        for i in range(count):
            angle = random.uniform(math.radians(15), math.radians(165))
            dx, dy = math.cos(angle), math.sin(angle)

            # Normal vector and a modest offset from the origin.
            nx, ny = -dy, dx
            offset = random.uniform(-6.5, 6.5)
            A, B = nx, ny
            C = -offset

            line = Line(A, B, C, "hawk path")

            # Spread starting positions but bias many toward the central region.
            if i < max(1, count // 2):
                t = random.uniform(-8, 8)
            else:
                t = random.uniform(-16, 16)

            speed = random.uniform(3.8, 7.8)
            direction = random.choice((-1, 1))
            hawks.append(Hawk(line, t, direction, speed))

        return hawks

    def create_circle(self):
        text = self.circle_input.text.strip()
        if not text:
            self.remove_circle()
            return

        try:
            value = float(text)
            if value <= 0:
                raise ValueError
            radius = math.sqrt(value)
            if radius > 30:
                self.message = "That circle is too large for this game."
                self.message_colour = RED
                return
        except ValueError:
            self.message = "Enter a positive number for x² + y²."
            self.message_colour = RED
            return

        self.circle_radius = radius

        caught = 0
        for hawk in self.hawks:
            hx, hy = hawk.position()
            hawk.allowed_inside = math.hypot(hx, hy) <= radius
            if hawk.allowed_inside:
                caught += 1

        outside = len(self.hawks) - caught
        if outside == 0:
            self.message = "Circle added. All hawks trapped. Safe to go!"
            self.message_colour = DARK_GREEN
        elif caught > 0 and outside <= 3:
            self.message = "Circle added. Safer to go. Still be careful!"
            self.message_colour = ORANGE
        else:
            self.message = "Circle added. Still dangerous!"
            self.message_colour = RED

    def remove_circle(self):
        self.circle_radius = None
        self.circle_input.text = ""
        for hawk in self.hawks:
            hawk.allowed_inside = None
        self.message = "Circle removed."
        self.message_colour = BLACK

    def add_line(self):
        text = self.line_input.text.strip()
        if not text:
            return
        try:
            line = parse_linear_equation(text)
        except Exception as exc:
            self.message = str(exc) if str(exc) else "Enter a valid linear equation."
            self.message_colour = RED
            return

        self.lines.append(line)
        self.line_input.text = ""
        if len(self.lines) == 1:
            self.message = "Line added."
        else:
            self.message = (
                "Line added. At a highlighted intersection, release the current "
                "arrow key or press a new arrow key to switch lines."
            )
        self.message_colour = BLUE

    def delete_latest_line(self):
        if not self.lines:
            self.message = "There are no lines to erase."
            self.message_colour = GREY
            return

        removed = self.lines.pop()

        if self.turtle_line is removed:
            self.fall_facing_angle = self.turtle_angle
            self.turtle_line = None
            self.turtle_path = None
            self.falling = True
            self.fall_old_y = self.turtle_y
            self.message = "You erased the turtle's path — it's falling!"
            self.message_colour = RED
        else:
            self.message = "Most recent line erased."
            self.message_colour = BLACK

    def nearest_usable_intersection(self):
        """Find the closest valid intersection with ANY other student line."""
        if not self.lines or self.falling or self.turtle_path == "finish":
            return None, None

        best_line = None
        best_point = None
        best_distance = float("inf")

        for candidate in self.lines:
            if candidate is self.turtle_line:
                continue

            p = None

            if self.turtle_path == "start":
                if abs(candidate.A) < 1e-9:
                    continue
                ix = -(candidate.B * self.start_y + candidate.C) / candidate.A
                if self.start_x1 <= ix <= self.start_x2:
                    p = (ix, self.start_y)

            elif self.turtle_line is not None:
                p = self.turtle_line.intersection(candidate)
                if p is not None:
                    if not (MIN_COORD <= p[0] <= MAX_COORD and MIN_COORD <= p[1] <= MAX_COORD):
                        p = None

            if p is None:
                continue

            distance = math.dist((self.turtle_x, self.turtle_y), p)
            if distance < best_distance:
                best_distance = distance
                best_line = candidate
                best_point = p

        return best_line, best_point

    def near_intersection(self):
        """Return the nearest intersection only while the turtle is in contact with it."""
        line, p = self.nearest_usable_intersection()
        if line is None or p is None:
            return None, None
        if math.dist((self.turtle_x, self.turtle_y), p) <= INTERSECTION_TOL:
            return line, p
        return None, None

    def direction_for_key(self, line, key_name):
        """Return a unit direction along line that matches the arrow key."""
        dx, dy = line.dx, line.dy
        eps = 1e-9

        if key_name == "right":
            if abs(dx) < eps:
                return None
            if dx < 0:
                dx, dy = -dx, -dy
        elif key_name == "left":
            if abs(dx) < eps:
                return None
            if dx > 0:
                dx, dy = -dx, -dy
        elif key_name == "up":
            if abs(dy) < eps:
                return None
            if dy < 0:
                dx, dy = -dx, -dy
        elif key_name == "down":
            if abs(dy) < eps:
                return None
            if dy > 0:
                dx, dy = -dx, -dy
        else:
            return None

        return dx, dy

    def switch_to_line(self, key_name):
        line, p = self.near_intersection()
        if line is None or p is None:
            return False

        direction = self.direction_for_key(line, key_name)
        if direction is None:
            return False

        self.turtle_x, self.turtle_y = p
        dx, dy = direction
        self.turtle_line = line
        self.turtle_path = "line"
        self.turtle_angle = math.degrees(math.atan2(dy, dx))
        self.message = "Path changed."
        self.message_colour = BLUE
        return True

    def horizontal_start_line(self):
        """Return the newest horizontal line matching the start ledge."""
        for line in reversed(self.lines):
            if (abs(line.A) < 1e-9 and abs(line.B) > 1e-9
                    and abs(line.y_at(0) - self.start_y) < 1e-6):
                return line
        return None

    def move_turtle(self, dt, keys):
        if self.falling:
            return

        amount = TURTLE_SPEED * dt
        old_x, old_y = self.turtle_x, self.turtle_y

        pressed = []
        if keys[pygame.K_UP]:
            pressed.append("up")
        if keys[pygame.K_RIGHT]:
            pressed.append("right")
        if keys[pygame.K_DOWN]:
            pressed.append("down")
        if keys[pygame.K_LEFT]:
            pressed.append("left")

        if not pressed:
            return

        # Holding an arrow does not switch paths automatically.
        # A switch requires a fresh KEYDOWN while touching an intersection.
        # The player can release and press the same arrow again, or press a
        # different arrow, to choose the intersecting path.

        if self.turtle_path == "start":
            # Start ledge is horizontal: LEFT/RIGHT only.
            if "right" in pressed:
                move_sign = 1
            elif "left" in pressed:
                move_sign = -1
            else:
                return

            self.turtle_x += move_sign * amount
            self.turtle_angle = 0 if move_sign > 0 else 180

            attempted_x = self.turtle_x
            inside_edge = self.start_x2 if self.start_side == "left" else self.start_x1
            self.turtle_x = max(self.start_x1, min(self.start_x2, self.turtle_x))
            leaving_inside = ((self.start_side == "left" and attempted_x > inside_edge)
                              or (self.start_side == "right" and attempted_x < inside_edge))
            if leaving_inside:
                start_line = self.horizontal_start_line()
                toward_centre = ((self.start_side == "left" and move_sign > 0)
                                 or (self.start_side == "right" and move_sign < 0))
                if start_line is not None and toward_centre:
                    self.turtle_path = "line"
                    self.turtle_line = start_line
                    self.turtle_x = inside_edge
                    self.turtle_y = self.start_y
                    self.turtle_angle = 0 if move_sign > 0 else 180
                else:
                    self.turtle_x = inside_edge + (0.03 if self.start_side == "left" else -0.03)
                    self.turtle_path = None
                    self.fall_facing_angle = self.turtle_angle
                    self.falling = True
                    self.fall_old_y = self.turtle_y
            return

        if self.turtle_path == "finish":
            if "right" in pressed:
                move_sign = 1
            elif "left" in pressed:
                move_sign = -1
            else:
                return

            self.turtle_x += move_sign * amount
            self.turtle_angle = 0 if move_sign > 0 else 180
            self.turtle_x = max(self.finish_x1, min(self.finish_x2, self.turtle_x))
            return

        if self.turtle_line is not None:
            direction = None
            for key_name in pressed:
                direction = self.direction_for_key(self.turtle_line, key_name)
                if direction is not None:
                    break

            if direction is None:
                return

            dx, dy = direction
            self.turtle_x += dx * amount
            self.turtle_y += dy * amount
            self.turtle_angle = math.degrees(math.atan2(dy, dx))
            self.check_line_arrival(old_x, old_y)

    def check_line_arrival(self, old_x, old_y):
        # A horizontal path at the safe-zone height can enter directly.
        if (
            self.turtle_line is not None
            and abs(self.turtle_y - self.finish_y) < 1e-6
            and self.finish_x1 <= self.turtle_x <= self.finish_x2
        ):
            self.turtle_x = max(self.finish_x1, min(self.finish_x2, self.turtle_x))
            self.turtle_y = self.finish_y
            self.turtle_path = "finish"
            self.turtle_line = None
            self.turtle_angle = 0
            return

        # Any other line that crosses the safe-zone height inside its ledge lands there.
        if (
            self.turtle_line is not None
            and (old_y - self.finish_y) * (self.turtle_y - self.finish_y) <= 0
            and abs(self.turtle_y - old_y) > 1e-8
        ):
            t = (self.finish_y - old_y) / (self.turtle_y - old_y)
            cross_x = old_x + t * (self.turtle_x - old_x)

            if self.finish_x1 <= cross_x <= self.finish_x2:
                self.turtle_x = cross_x
                self.turtle_y = self.finish_y
                self.turtle_path = "finish"
                self.turtle_line = None
                self.turtle_angle = 0
                return

        # Touching any graph border while on a student line ends the attempt.
        # The physical START and SAFE ZONE are handled separately above.
        if (
            self.turtle_x <= MIN_COORD
            or self.turtle_x >= MAX_COORD
            or self.turtle_y <= MIN_COORD
            or self.turtle_y >= MAX_COORD
        ):
            self.turtle_x = max(MIN_COORD, min(MAX_COORD, self.turtle_x))
            self.turtle_y = max(MIN_COORD, min(MAX_COORD, self.turtle_y))
            self.game_over("The turtle left the game world.")

    def update_fall(self, dt):
        if not self.falling:
            return

        old_y = self.turtle_y
        new_y = self.turtle_y - FALL_SPEED * dt

        # Find the highest student line crossed during this downward step.
        best = None
        for line in self.lines:
            if line.vertical:
                continue
            ly = line.y_at(self.turtle_x)
            if ly is None:
                continue
            if new_y - LAND_TOL <= ly <= old_y + LAND_TOL:
                if best is None or ly > best[0]:
                    best = (ly, line)

        # Physical ledges can also catch the turtle.
        if self.start_x1 <= self.turtle_x <= self.start_x2 and new_y <= self.start_y <= old_y:
            if best is None or self.start_y > best[0]:
                best = (self.start_y, "start")

        if self.finish_x1 <= self.turtle_x <= self.finish_x2 and new_y <= self.finish_y <= old_y:
            if best is None or self.finish_y > best[0]:
                best = (self.finish_y, "finish")

        if best is not None:
            self.turtle_y = best[0]
            self.falling = False
            facing_radians = math.radians(self.fall_facing_angle)
            facing_x = math.cos(facing_radians)
            facing_y = math.sin(facing_radians)
            if best[1] == "start":
                self.turtle_path = "start"
                self.turtle_line = None
                self.turtle_angle = 180 if facing_x < 0 else 0
            elif best[1] == "finish":
                self.turtle_path = "finish"
                self.turtle_line = None
                self.turtle_angle = 180 if facing_x < 0 else 0
            else:
                self.turtle_path = "line"
                self.turtle_line = best[1]

                # Match the line's slope while preserving the turtle's
                # pre-fall facing direction instead of always pointing right.
                dx, dy = best[1].dx, best[1].dy
                if dx * facing_x + dy * facing_y < 0:
                    dx, dy = -dx, -dy
                self.turtle_angle = math.degrees(math.atan2(dy, dx))
            self.message = "The turtle landed on a path!"
            self.message_colour = BLUE
            return

        self.turtle_y = new_y
        self.turtle_angle = -90

        if self.turtle_y < MIN_COORD - 1:
            self.game_over("The turtle fell out of the game world.")

    def check_hawk_collision(self):
        if self.state != "playing":
            return
        for hawk in self.hawks:
            hx, hy = hawk.position()
            if math.dist((hx, hy), (self.turtle_x, self.turtle_y)) <= HAWK_RADIUS + TURTLE_RADIUS:
                self.game_over("A hawk caught the turtle!")
                return

    def check_obstacle_collision(self):
        if self.state != "playing":
            return
        for polygon in self.obstacles:
            if point_in_polygon(self.turtle_x, self.turtle_y, polygon):
                self.game_over("The turtle hit an obstacle!")
                return
            for i, (x1, y1) in enumerate(polygon):
                x2, y2 = polygon[(i + 1) % len(polygon)]
                if distance_to_segment(self.turtle_x, self.turtle_y, x1, y1, x2, y2) <= TURTLE_RADIUS:
                    self.game_over("The turtle hit an obstacle!")
                    return

    def check_finish(self):
        if self.state != "playing":
            return
        # Reaching any part of the physical SAFE ZONE completes the round.
        # Do not require the player to move an additional unit along the ledge.
        if self.turtle_path == "finish":
            self.finish_level_score()
            if self.level == len(HAWK_COUNTS) - 1:
                self.state = "won"
            else:
                self.state = "level_complete"

    def game_over(self, reason):
        self.state = "game_over"
        self.message = reason
        self.message_colour = RED

    def update(self, dt):
        if self.state == "won":
            self.dance_time += dt
            return
        if self.state == "level_complete":
            return
        if self.state != "playing":
            return

        old_position = (self.turtle_x, self.turtle_y)

        for hawk in self.hawks:
            hawk.update(dt, self.circle_radius)

        keys = pygame.key.get_pressed()
        if not self.line_input.active and not self.circle_input.active:
            self.move_turtle(dt, keys)
        else:
            self.vertical_move_key = None
        self.update_fall(dt)
        self.actual_distance += math.dist(old_position, (self.turtle_x, self.turtle_y))
        # Reaching safety takes priority and immediately opens the results screen.
        self.check_finish()
        if self.state != "playing":
            return
        self.check_obstacle_collision()
        self.check_hawk_collision()

    def handle_event(self, event):
        if self.state == "game_over":
            if self.retry_button.clicked(event):
                self.start_level()
            return

        if self.state == "level_complete":
            if self.next_button.clicked(event):
                self.level += 1
                self.start_level()
            return

        if self.state == "won":
            if self.restart_button.clicked(event):
                self.level = 0
                self.level_scores = []
                self.last_level_score = None
                self.start_level()
            return

        # Switch only on a NEW arrow-key press while touching a intersection.
        if (
            event.type == pygame.KEYDOWN
            and not self.line_input.active
            and not self.circle_input.active
        ):
            key_names = {
                pygame.K_UP: "up",
                pygame.K_RIGHT: "right",
                pygame.K_DOWN: "down",
                pygame.K_LEFT: "left",
            }
            key_name = key_names.get(event.key)
            if key_name is not None:
                self.switch_to_line(key_name)

        line_submit, line_empty_backspace = self.line_input.handle_event(event)
        circle_submit, circle_empty_backspace = self.circle_input.handle_event(event)

        if line_submit:
            self.add_line()
        if line_empty_backspace:
            self.delete_latest_line()

        if circle_submit:
            self.create_circle()
        if circle_empty_backspace:
            self.remove_circle()

    # -------------------- DRAWING --------------------
    def draw_grid(self):
        pygame.draw.rect(
            SCREEN,
            WHITE,
            (GRAPH_LEFT, GRAPH_TOP, GRAPH_SIZE, GRAPH_SIZE),
        )

        for n in range(MIN_COORD, MAX_COORD + 1):
            sx, _ = graph_to_screen(n, 0)
            _, sy = graph_to_screen(0, n)
            pygame.draw.line(SCREEN, GRID, (sx, GRAPH_TOP), (sx, GRAPH_TOP + GRAPH_SIZE), 1)
            pygame.draw.line(SCREEN, GRID, (GRAPH_LEFT, sy), (GRAPH_LEFT + GRAPH_SIZE, sy), 1)

        x0, y0 = graph_to_screen(0, 0)
        pygame.draw.line(SCREEN, AXIS, (GRAPH_LEFT, y0), (GRAPH_LEFT + GRAPH_SIZE, y0), 2)
        pygame.draw.line(SCREEN, AXIS, (x0, GRAPH_TOP), (x0, GRAPH_TOP + GRAPH_SIZE), 2)

        # Labels every 5 units.
        for n in range(MIN_COORD, MAX_COORD + 1, 5):
            if n == 0:
                continue
            sx, sy0 = graph_to_screen(n, 0)
            label = TINY_FONT.render(str(n), True, GREY)
            SCREEN.blit(label, (sx - label.get_width() // 2, sy0 + 4))

            sx0, sy = graph_to_screen(0, n)
            label = TINY_FONT.render(str(n), True, GREY)
            SCREEN.blit(label, (sx0 + 5, sy - label.get_height() // 2))

        pygame.draw.rect(
            SCREEN,
            BLACK,
            (GRAPH_LEFT, GRAPH_TOP, GRAPH_SIZE, GRAPH_SIZE),
            2,
        )

    def draw_platforms(self):
        # Start ledge
        s1 = graph_to_screen(self.start_x1, self.start_y)
        s2 = graph_to_screen(self.start_x2, self.start_y)
        pygame.draw.line(SCREEN, BROWN, s1, s2, 10)
        label = SMALL_FONT.render("START", True, BROWN)
        #SCREEN.blit(label, (min(s1[0], s2[0]) + 3, s1[1] + 10))
        SCREEN.blit(label, ((s1[0] + s2[0]) // 2 - label.get_width() // 2, s1[1] + 10))

        # Finish ledge
        f1 = graph_to_screen(self.finish_x1, self.finish_y)
        f2 = graph_to_screen(self.finish_x2, self.finish_y)
        pygame.draw.line(SCREEN, GREEN, f1, f2, 10)
        label = SMALL_FONT.render("SAFE ZONE", True, DARK_GREEN)
        #SCREEN.blit(label, (min(f1[0], f2[0]) + 3, f1[1] + 10))
        SCREEN.blit(label,((f1[0] + f2[0]) // 2 - label.get_width() // 2,f1[1] + 10))

    def draw_obstacles(self):
        for polygon in self.obstacles:
            points = [graph_to_screen(x, y) for x, y in polygon]
            pygame.draw.polygon(SCREEN, OBSTACLE_RED, points, 4)

    def draw_student_lines(self):
        highlighted_line, highlighted_point = self.near_intersection()

        for line in self.lines:
            pts = line.visible_endpoints()
            if len(pts) != 2:
                continue
            p1 = graph_to_screen(*pts[0])
            p2 = graph_to_screen(*pts[1])

            colour = PURPLE
            width = 3
            if line is highlighted_line:
                colour = YELLOW
                width = 6

            pygame.draw.line(SCREEN, colour, p1, p2, width)

        if highlighted_point is not None:
            sx, sy = graph_to_screen(*highlighted_point)
            pygame.draw.circle(SCREEN, YELLOW, (sx, sy), 9, 3)

    def draw_circle(self):
        if self.circle_radius is None:
            return
        cx, cy = graph_to_screen(0, 0)
        radius_px = int(self.circle_radius * SCALE)
        if radius_px > 0:
            pygame.draw.circle(SCREEN, BLUE, (cx, cy), radius_px, 4)

    def make_turtle_surface(self, size_multiplier=1.0):
        """Create the turtle image used both in play and in celebrations."""
        w = max(18, int(1.65 * SCALE * size_multiplier))
        h = max(12, int(1.05 * SCALE * size_multiplier))
        surf = pygame.Surface((w, h), pygame.SRCALPHA)

        # Tail and four feet sit behind the shell.
        pygame.draw.polygon(
            surf, DARK_GREEN,
            [(int(w * 0.12), h // 2), (0, int(h * 0.38)), (0, int(h * 0.62))],
        )
        foot_r = max(2, int(h * 0.13))
        for fx, fy in ((0.28, 0.16), (0.28, 0.84), (0.65, 0.16), (0.65, 0.84)):
            pygame.draw.circle(surf, DARK_GREEN, (int(w * fx), int(h * fy)), foot_r)
            pygame.draw.circle(surf, BLACK, (int(w * fx), int(h * fy)), foot_r, 1)

        # Oval shell with a simple inner pattern.
        shell = pygame.Rect(int(w * 0.12), int(h * 0.18), int(w * 0.65), int(h * 0.64))
        pygame.draw.ellipse(surf, GREEN, shell)
        pygame.draw.ellipse(surf, BLACK, shell, max(1, int(size_multiplier)))
        inner = shell.inflate(-max(4, int(w * 0.16)), -max(3, int(h * 0.20)))
        if inner.width > 2 and inner.height > 2:
            pygame.draw.ellipse(surf, DARK_GREEN, inner, max(1, int(size_multiplier)))

        # Head, eye and smile make its direction obvious.
        head_r = max(3, int(h * 0.22))
        head = (int(w * 0.84), h // 2)
        pygame.draw.circle(surf, DARK_GREEN, head, head_r)
        pygame.draw.circle(surf, BLACK, head, head_r, max(1, int(size_multiplier)))
        eye = (head[0] + max(1, head_r // 3), head[1] - max(1, head_r // 3))
        pygame.draw.circle(surf, WHITE, eye, max(1, head_r // 4))
        pygame.draw.circle(surf, BLACK, eye, max(1, head_r // 7))
        return surf

    def draw_turtle(self):
        sx, sy = graph_to_screen(self.turtle_x, self.turtle_y)
        surf = self.make_turtle_surface()

        rotated = pygame.transform.rotate(surf, self.turtle_angle)
        rect = rotated.get_rect(center=(sx, sy))
        SCREEN.blit(rotated, rect)

    def draw_dancing_turtle(self, card, score):
        """Animate one of three final celebrations selected by the average score."""
        t = self.dance_time
        centre_x = card.centerx
        base_y = card.y + 220
        turtle = self.make_turtle_surface(2.65)

        if score < 50:
            # A simple dubstep-style wobble and bounce.
            x = centre_x + math.sin(t * 5.0) * 24
            y = base_y + math.sin(t * 10.0) * 7
            angle = math.sin(t * 7.0) * 22
            dance_name = "Turtle wobble!"
        elif score < 80:
            # A more energetic jump with continuous spins.
            x = centre_x + math.sin(t * 3.2) * 38
            y = base_y - abs(math.sin(t * 3.5)) * 38
            angle = (t * 210) % 360
            dance_name = "Turtle dance!"
        else:
            # A repeating routine: footwork, aerial spin, shell spin, pose.
            phase = t % 6.4
            if phase < 1.4:
                x = centre_x + math.sin(t * 10.0) * 34
                y = base_y + math.sin(t * 20.0) * 5
                angle = math.sin(t * 12.0) * 25
                dance_name = "Hero in a half-shell!"
            elif phase < 2.7:
                progress = (phase - 1.4) / 1.3
                x = centre_x + math.sin(progress * math.pi * 2) * 28
                y = base_y - math.sin(progress * math.pi) * 55
                angle = progress * 720
                dance_name = "Turtle power!"
            elif phase < 5.2:
                x = centre_x + math.sin(t * 5.0) * 45
                y = base_y - abs(math.sin(t * 6.0)) * 16
                angle = (t * 760) % 360
                turtle = pygame.transform.scale(
                    turtle,
                    (turtle.get_width(), max(10, int(turtle.get_height() * 0.58))),
                )
                dance_name = "Breakdancing victory spin!"
            else:
                x = centre_x
                y = base_y - abs(math.sin(t * 4.5)) * 28
                angle = math.sin(t * 5.0) * 12
                dance_name = "Cowabunga! Your math skills are totally radical!"

            # Celebration sparks orbit the spinning turtle.
            colours = (YELLOW, ORANGE, BLUE, PURPLE, GREEN)
            for i in range(18):
                spark_angle = t * 2.2 + i * (2 * math.pi / 18)
                radius = 70 + 12 * math.sin(t * 3 + i)
                px = int(x + math.cos(spark_angle) * radius)
                py = int(y + math.sin(spark_angle) * radius * 0.48)
                pygame.draw.circle(SCREEN, colours[i % len(colours)], (px, py), 4)

        rotated = pygame.transform.rotozoom(turtle, angle, 1.0)
        SCREEN.blit(rotated, rotated.get_rect(center=(int(x), int(y))))

        label = SMALL_FONT.render(dance_name, True, DARK_GREEN)
        SCREEN.blit(label, (card.centerx - label.get_width() // 2, card.y + 268))

    def draw_score_history(self, card, start_y):
        """Draw all completed round scores in two columns."""
        for index, round_score in enumerate(self.level_scores):
            column = index // 5
            row = index % 5
            x = card.x + 55 + column * (card.width // 2)
            y = start_y + row * 30
            result = SMALL_FONT.render(
                f"Round {index + 1}: {round_score:.1f} / 100", True, PURPLE
            )
            SCREEN.blit(result, (x, y))

    def draw_round_score_card(self):
        """Static, unmistakable results screen shown after rounds 1–9."""
        card = pygame.Rect(GRAPH_LEFT + 145, GRAPH_TOP + 155, 470, 420)
        pygame.draw.rect(SCREEN, WHITE, card, border_radius=14)
        pygame.draw.rect(SCREEN, DARK_GREEN, card, 4, border_radius=14)

        heading = BIG_FONT.render("ROUND COMPLETE", True, DARK_GREEN)
        SCREEN.blit(heading, (card.centerx - heading.get_width() // 2, card.y + 20))

        current_round = len(self.level_scores)
        score_banner = pygame.Rect(card.x + 25, card.y + 65, card.width - 50, 64)
        pygame.draw.rect(SCREEN, BLUE, score_banner, border_radius=10)
        pygame.draw.rect(SCREEN, BLACK, score_banner, 2, border_radius=10)
        score_text = FONT.render(
            f"ROUND {current_round} SCORE: {self.last_level_score:.1f} / 100",
            True, WHITE,
        )
        SCREEN.blit(score_text, score_text.get_rect(center=score_banner.center))

        details = SMALL_FONT.render(
            f"Minimum: {self.minimum_distance:.1f}   Travelled: {self.actual_distance:.1f}",
            True, BLACK,
        )
        SCREEN.blit(details, (card.centerx - details.get_width() // 2, card.y + 145))

        history_title = FONT.render("Scores so far", True, BLACK)
        SCREEN.blit(history_title, (card.centerx - history_title.get_width() // 2, card.y + 185))
        self.draw_score_history(card, card.y + 225)

        continue_text = SMALL_FONT.render("Click Next Level to continue", True, GREY)
        SCREEN.blit(continue_text, (card.centerx - continue_text.get_width() // 2, card.y + 380))

    def draw_final_celebration(self):
        """Dance only after round 10, while showing the overall average."""
        average = sum(self.level_scores) / len(self.level_scores)
        card = pygame.Rect(GRAPH_LEFT + 90, GRAPH_TOP + 45, 580, 670)
        pygame.draw.rect(SCREEN, WHITE, card, border_radius=14)
        pygame.draw.rect(SCREEN, DARK_GREEN, card, 4, border_radius=14)

        heading = BIG_FONT.render("ALL 10 ROUNDS COMPLETE!", True, DARK_GREEN)
        SCREEN.blit(heading, (card.centerx - heading.get_width() // 2, card.y + 18))

        average_banner = pygame.Rect(card.x + 45, card.y + 62, card.width - 90, 62)
        pygame.draw.rect(SCREEN, BLUE, average_banner, border_radius=10)
        pygame.draw.rect(SCREEN, BLACK, average_banner, 2, border_radius=10)
        average_text = TITLE_FONT.render(
            f"AVERAGE SCORE: {average:.1f} / 100", True, WHITE
        )
        SCREEN.blit(average_text, average_text.get_rect(center=average_banner.center))

        if average >= 95:
            cowabunga = FONT.render("COWABUNGA!! BODACIOUSLY RADICAL MATH SKILLS!!!", True, ORANGE)
            SCREEN.blit(cowabunga, (card.centerx - cowabunga.get_width() // 2, card.y + 137))

        self.draw_dancing_turtle(card, average)

        history_title = FONT.render("Final round scores", True, BLACK)
        SCREEN.blit(history_title, (card.centerx - history_title.get_width() // 2, card.y + 310))
        self.draw_score_history(card, card.y + 350)

        restart_text = SMALL_FONT.render("Click Restart Game to play again", True, GREY)
        SCREEN.blit(restart_text, (card.centerx - restart_text.get_width() // 2, card.y + 625))

    def draw_score_card(self):
        if self.last_level_score is None:
            return
        if self.state == "level_complete":
            self.draw_round_score_card()
        elif self.state == "won":
            self.draw_final_celebration()

    def draw_panel(self):
        pygame.draw.rect(SCREEN, LIGHT_PANEL, (800, 0, 400, HEIGHT))

        SCREEN.blit(TITLE_FONT.render("Turtle Line Escape", True, BLACK), (PANEL_LEFT, 25))
        SCREEN.blit(
            SMALL_FONT.render(
                f"Level {self.level + 1}/10 • {HAWK_COUNTS[self.level]} hawks • {len(self.obstacles)} obstacles",
                True,
                BLUE,
            ),
            (PANEL_LEFT, 68),
        )

        SCREEN.blit(FONT.render("Create a linear path", True, BLACK), (PANEL_LEFT, 120))
        self.line_input.draw()
        SCREEN.blit(
            SMALL_FONT.render("Use y = mx + b, y = b, or x = a", True, GREY),
            (PANEL_LEFT, 215),
        )
        SCREEN.blit(
            SMALL_FONT.render("Example: y = 0.5x + 7", True, GREY),
            (PANEL_LEFT, 238),
        )
        SCREEN.blit(
            SMALL_FONT.render("Backspace on empty box erases newest line", True, GREY),
            (PANEL_LEFT, 261),
        )

        SCREEN.blit(FONT.render("Trap hawks with a circle", True, BLACK), (PANEL_LEFT, 295))
        SCREEN.blit(FONT.render("x² + y² =", True, BLACK), (PANEL_LEFT, 352))
        # Compact box placed close to x² + y² =
        self.circle_input.rect.x = PANEL_LEFT + 89
        self.circle_input.rect.y = 345
        self.circle_input.rect.width = 74
        self.circle_input.draw()
        SCREEN.blit(
            SMALL_FONT.render("Enter r²", True, GREY),
            (PANEL_LEFT, 397),
        )
        SCREEN.blit(
            SMALL_FONT.render("Example: 25 (for a circle with radius 5)", True, GREY),
            (PANEL_LEFT, 420),
        )
        SCREEN.blit(
            SMALL_FONT.render("Backspace on empty box removes circle", True, GREY),
            (PANEL_LEFT, 443),
        )

        SCREEN.blit(FONT.render("Controls", True, BLACK), (PANEL_LEFT, 480))
        controls = [
            "Enter: Submit the active input",
            "Arrows: Move the turtle along a line",
        ]
        yy = 515
        for text in controls:
            SCREEN.blit(SMALL_FONT.render(text, True, BLACK), (PANEL_LEFT, yy))
            yy += 27

        SCREEN.blit(FONT.render("Status", True, BLACK), (PANEL_LEFT, 585))
        yy = 620
        for line in wrap_text(self.message, SMALL_FONT, 345):
            SCREEN.blit(SMALL_FONT.render(line, True, self.message_colour), (PANEL_LEFT, yy))
            yy += 23

        if self.state == "game_over":
            SCREEN.blit(BIG_FONT.render("GAME OVER", True, RED), (PANEL_LEFT, 690))
            self.retry_button.draw()
        elif self.state == "level_complete":
            SCREEN.blit(BIG_FONT.render("LEVEL COMPLETE!", True, DARK_GREEN), (PANEL_LEFT, 685))
            self.next_button.draw()
        elif self.state == "won":
            SCREEN.blit(BIG_FONT.render("GOOD JOB!", True, DARK_GREEN), (PANEL_LEFT, 685))
            average = sum(self.level_scores) / len(self.level_scores) if self.level_scores else 0.0
            SCREEN.blit(
                SMALL_FONT.render(f"Final average: {average:.1f}/100", True, BLUE),
                (PANEL_LEFT, 725),
            )
            self.restart_button.draw()

    def draw(self):
        SCREEN.fill(WHITE)
        self.draw_grid()
        self.draw_platforms()
        self.draw_student_lines()
        self.draw_circle()
        self.draw_obstacles()

        for hawk in self.hawks:
            hawk.draw()

        self.draw_turtle()
        self.draw_score_card()
        self.draw_panel()


async def main():
    game = Game()
    running = True

    while running:
        dt = min(CLOCK.tick(60) / 1000.0, 0.05)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            else:
                game.handle_event(event)

        game.update(dt)
        game.draw()
        pygame.display.flip()

        # Let the browser process input and display each frame.
        await asyncio.sleep(0)

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
